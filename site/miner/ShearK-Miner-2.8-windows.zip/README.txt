ShearK-Miner 2.8
Keep every DLL in this zip next to ShearK-Miner.exe.
Public pool: stratum+ssl://pool.shear.digital:443
Localhost solo: stratum+tcp://127.0.0.1:1111

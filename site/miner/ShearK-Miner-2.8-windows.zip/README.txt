ShearK-Miner 2.8
Keep every DLL in this zip next to ShearK-Miner.exe.
Sample launchers in this zip: example.bat and example.sh.
Windows: edit example.bat, then double-click it.
Public pool: stratum+ssl://pool.shear.digital:443
Localhost solo: stratum+tcp://127.0.0.1:1111
Do not pass --tls-pin. There is no --tls-insecure.
